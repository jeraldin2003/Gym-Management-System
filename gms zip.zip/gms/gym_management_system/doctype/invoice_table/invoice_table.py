# Copyright (c) 2024, Jerald and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class InvoiceTable(Document):










	
	"""def before_save(self):
		self.classe_attended='working'
		self.lockerr_booked='working'
		self.membership_taken='working'
		self.cost_of_classes='working'
		self.cost_of_lockers='working'
		self.cost_of_membership='working'"""