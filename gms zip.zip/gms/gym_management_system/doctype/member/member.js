// Copyright (c) 2024, Jerald and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Member", {
// 	refresh(frm) {

// 	},
// });
